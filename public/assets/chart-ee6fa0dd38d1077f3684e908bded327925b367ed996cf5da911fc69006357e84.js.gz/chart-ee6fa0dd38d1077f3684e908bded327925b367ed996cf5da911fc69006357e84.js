import "chartkick"
import "Chart.bundle";
