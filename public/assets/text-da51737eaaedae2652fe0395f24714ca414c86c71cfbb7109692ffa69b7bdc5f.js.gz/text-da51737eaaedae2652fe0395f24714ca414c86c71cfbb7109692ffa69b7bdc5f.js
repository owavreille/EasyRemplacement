import 'trix'
import '@rails/actiontext';
