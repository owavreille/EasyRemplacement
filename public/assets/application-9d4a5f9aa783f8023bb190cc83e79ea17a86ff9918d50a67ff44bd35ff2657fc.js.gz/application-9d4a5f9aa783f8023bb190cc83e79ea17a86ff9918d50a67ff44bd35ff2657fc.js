import 'jquery'
import 'jquery_ujs'
import 'popper'
import 'bootstrap'
import '@hotwired/turbo-rails'
import 'controllers'
import "custom/trix";
